<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <title>Upfront Discrepancies</title>
    <style>
        table {
            border: 0;
            border-collapse: separate;
            border-spacing: 0 5px;
        }

        .thead_style tr th {
            border-bottom: 1px solid grey;
            font-family: system-ui, system-ui, sans-serif;
            border-collapse: separate;
            border-spacing: 5px 5px;
            text-align: left;
            font-weight: 800;
            font-size: 12px;
        }
        .subtotal tr th {
            border-top: 1px solid grey;
            font-family: system-ui, system-ui, sans-serif;
            border-collapse: separate;
            border-spacing: 5px 5px;
            text-align: left;
            font-size: 12px;
        }.grand_total tr th {
             border-top: 2px solid grey;
             font-family: system-ui, system-ui, sans-serif;
             border-collapse: separate;
             border-spacing: 5px 5px;
             text-align: left;
             font-size: 14px;
         }
        .body_class tr td {
            font-family: system-ui, system-ui, sans-serif;
            border-collapse: separate;
            border-spacing: 5px 5px;
            text-align: left;
            font-size: 12px;
        }
        .body_class tbody{
            border-collapse: separate;
            border-spacing: 5px 5px;
            border-bottom: 1px solid;
        }
        thead{display: table-header-group;}
        tfoot {display: table-row-group;}
        tr {page-break-inside: avoid;}
    </style>
</head>
<body style=" font-family: system-ui, system-ui, sans-serif;">


<table style="margin-top: 5px;margin-bottom:5px;width: 100%">
    <tbody>
    <tr>
        <td style="width: 25%"> <span style="font-size: 18px;font-weight: bold;">FM Direct Upfront Discrepancies</span></td>
        <td> <span style="width: 60%;font-weight: bold;">Grouped By {{ $group_by }} For period from {{ $date_from.' to '.$date_to }}</span></td>
    </tr>
    </tbody>
</table>
<?php $total_broker_est_loan_amt=0;
$total_broker_est_upfront=0;
$total_broker_est_brokerage=0; ?>
@if(count($deals)>0)
    @foreach($deals as $deal)
        <table class="row" style="margin-top: 5px;margin-bottom:5px;width: 100%">
            <tbody>
            <tr>
                <td style="width: 25%;background-color: #ffff99"> <span style="font-weight: bold;"><?php
                        if($group_by=='BrokerStaff'){
                            echo $deal->broker_staff->surname??'';
                        }
                        ?></span></td>
                <td></td>
            </tr>
            </tbody>
        </table>
        <?php
        $broker_est_loan_amt=0;
        $total_upfront_amt=0;
        $total_upfront_received=0;


        ?>

        <table style="width: 100%;margin-top: 5px" >
            <thead class="thead_style">
            <tr>
                <th style="width: 3%">Deal</th>
                <th style="width: 15%">Client</th>
                <th style="width: 15%">Lender</th>
                <th style="width: 10%">Broker Staff</th>
                <th style="width: 8%">Loan Amount</th>
                <th style="width: 7%">Date Settled</th>
                <th style="width: 7%">Date Received</th>
                <th style="width: 7%">ABP Est. Upfront</th>
                <th style="width: 7%">Actual Upfront</th>
                <th style="width: 7%">Variance %</th>
            </tr>
            </thead>
            <tbody class="body_class">
            <?php $deals_list=\App\Models\Deal::query()->select('deals.*')->where('deals.broker_staff_id', $deal->broker_staff_id)->with(['lender', 'client', 'deal_status', 'product', 'broker', 'deal_commission'])->get(); ?>
            @foreach($deals_list as $deal_list)

                <?php
                $comm_created = 0;
                $upfront_received = 0;
                $total_upfront = 0;
                $upfront_precentage = 0;
                $deals_comm=\App\Models\DealCommission::query()->select('deal_commissions.*')->where(['type'=>13, 'deal_id'=>$deal_list->id])->get(); ?>
                @foreach($deals_comm as $comm)
                    <?php
                    $upfront_received = $comm->total_amount??0.00;
                    $total_upfront = $deal_list->broker_est_upfront??0.00;
                    if($total_upfront)  $upfront_precentage = round(( $upfront_received/ $total_upfront) * 100, 2);
                    $comm_created = date('m/d/Y',strtotime($comm->created_at))??'';
                    ?>
                    @if($upfront_precentage >= $variance)
                        <tr>
                            <td>{{ $deal_list->id }}</td>
                            <td>{{ $deal_list->client->surname??'' }}</td>
                            <td>{{ $deal_list->lender->name??'' }}</td>
                            <td>{{ $deal_list->broker_staff->surname??'' }}</td>
                            <td>${{ $deal_list->actual_loan??0.00 }}</td>
                            <td>{{ date('m/d/Y',strtotime($deal_list->created_at))??'' }}</td>
                            <td>{{$comm_created}}</td>
                            <td>${{$total_upfront}}</td>
                            <td>${{$upfront_received}}</td>
                            <td>{{$upfront_precentage}}%</td>

                        </tr>

                        <?php
                        $broker_est_loan_amt+=$deal_list->actual_loan;
                        $total_upfront_amt+=$total_upfront;
                        $total_upfront_received+=$upfront_received;
                        ?>
                    @endif
                @endforeach

            @endforeach
            </tbody>
            <thead class="subtotal" style="margin-top: 10px;">
            <tr>
                <th style="width: 3%"></th>
                <th style="width: 15%">Sub Totals</th>
                <th style="width: 15%"></th>
                <th style="width: 10%"></th>
                <th style="width: 7%">${{ $broker_est_loan_amt??0.00}}</th>
                <th style="width: 4%"></th>
                <th style="width: 7%"></th>
                <th style="width: 7%">${{$total_upfront_amt}}</th>
                <th style="width: 7%">${{$total_upfront_received}}</th>
                <th style="width: 7%"></th>
                <th style="width: 7%"></th>
            </tr>
            </thead>
        </table>
    @endforeach
@else
    <table style="width: 100%;margin-top: 5px" >
        <thead class="thead_style">
        <tr>
            <th style="width: 3%">Deal</th>
            <th style="width: 15%">Client</th>
            <th style="width: 15%">Lender</th>
            <th style="width: 10%">Broker Staff</th>
            <th style="width: 8%">Loan Amount</th>
            <th style="width: 4%">Date Settled</th>
            <th style="width: 7%">Date Received</th>
            <th style="width: 7%">ABP Est. Upfront</th>
            <th style="width: 7%">Actual Upfront</th>
            <th style="width: 7%">Line of Credit</th>
            <th style="width: 7%">Variance %</th>
        </tr>
        </thead>
        <tbody class="body_class">
        </tbody>
    </table>
@endif
@if(count($deals)>0)

    {{--    <table class="grand_total"  style="width: 100%">--}}
    {{--        <tr>--}}
    {{--            <th colspan="9"><?php--}}
    {{--                echo 'Grand Total'--}}
    {{--                ?></th>--}}
    {{--            <th style="text-align: left;width: 7%">${{ $total_broker_est_loan_amt }}</th>--}}
    {{--            <th style="text-align: left;width: 7%">${{$total_broker_est_upfront}}</th>--}}
    {{--            <th style="text-align: left;width: 7%">${{ $total_broker_est_brokerage }}</th>--}}
    {{--        </tr>--}}
    {{--    </table>--}}

@endif

</body>
</html>
