<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <title>Pipeline</title>

</head>
<body style=" font-family: system-ui, system-ui, sans-serif;">

<style>
    table {
        border: 0;
        border-collapse: separate;
        border-spacing: 0 5px;
    }

    .thead_style tr th {
        border-bottom: 1px solid grey;
        font-family: system-ui, system-ui, sans-serif;
        border-collapse: separate;
        border-spacing: 5px 5px;
        text-align: left;
        font-weight: 800;
        font-size: 12px;
    }
    .subtotal tr th {
        border-top: 1px solid grey;
        font-family: system-ui, system-ui, sans-serif;
        border-collapse: separate;
        border-spacing: 5px 5px;
        text-align: left;
        font-size: 12px;
    }.grand_total tr th {
         border-top: 2px solid grey;
         font-family: system-ui, system-ui, sans-serif;
         border-collapse: separate;
         border-spacing: 5px 5px;
         text-align: left;
         font-size: 14px;
     }
    .body_class tr td {
        font-family: system-ui, system-ui, sans-serif;
        border-collapse: separate;
        border-spacing: 5px 5px;
        text-align: left;
        font-size: 12px;
    }
    .body_class tbody{
        border-collapse: separate;
        border-spacing: 5px 5px;
        border-bottom: 1px solid;
    }
</style>
<table style="margin-top: 5px;margin-bottom:5px;width: 100%">
    <tbody>
    <tr>
        <td style="width: 25%"> <span style="font-size: 18px">Loans with trail but not received from lender</span></td>
    </tr>
    </tbody>
</table>

@if(is_array($lenders)&&count($lenders)>0)

    @foreach($lenders as $lender)
        <table class="row" style="margin-top: 5px;margin-bottom:5px;width: 100%">
            <tbody>
            <tr>
                <td style="width: 25%;background-color: #ffff99"> <span style="font-weight: bold;"><?php
                        echo $lender->name??'';
                        ?></span></td>
                <td></td>
            </tr>
            </tbody>
        </table>
        <?php
        $broker_est_loan_amt=0;
        $broker_est_upfront=0;
        $broker_est_brokerage=0;

        ?>

        <table style="width: 100%;margin-top: 5px" >
            <thead class="thead_style">
            <tr>
                <th>Client</th>
                <th>Consultant</th>
                <th>Loan Amount</th>
                <th>Product</th>
                <th>Deal Id</th>
                <th>Institution Ref</th>
                <th>Last Date</th>

            </tr>
            </thead>
            <tbody class="body_class">
            @if(is_array($lenders->deals)&&count($lenders->deals))
                @foreach($lenders->deals as $deal_list)
                    <?php
                    print_r('hi');exit;
                    $deal_trail=\App\Models\DealCommission::where('type',12)->where('deal_id'.$deal_list->id)->orderBy('id','desc')->first();
                    ?>
                    <tr>
                        <td>{{ $deal_list->client->surname }}</td>
                        <td>{{ $deal_list->lender->name }}</td>
                        <td>${{ $deal_list->actual_loan??'0' }}</td>
                        <td>{{ $deal_list->product->name }}</td>
                        <td>{{ $deal_list->id }}</td>
                        <td>{{ $deal_trail->broker_est_trail }}</td>
                        <td>{{ $deal_trail->broker_amount}}</td>
                    </tr>

                @endforeach
            @endif
            </tbody>
        </table>

    @endforeach
@else

    <table style="width: 100%;margin-top: 5px" >
        <thead class="thead_style">
        <tr>
            <th>Client</th>
            <th>Consultant</th>
            <th>Loan Amount</th>
            <th>Product</th>
            <th>Deal Id</th>
            <th>Institution Ref</th>
            <th>Last Date</th>
        </tr>
        </thead>
        <tbody class="body_class">
        </tbody>
    </table>
@endif

</body>
</html>
