<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <title>Pipeline</title>

</head>
<body style=" font-family: system-ui, system-ui, sans-serif;">

<style>
    table {
        border: 0;
        border-collapse: separate;
        border-spacing: 0 5px;
    }

    .thead_style tr th {
        border-bottom: 1px solid grey;
        font-family: system-ui, system-ui, sans-serif;
        border-collapse: separate;
        border-spacing: 5px 5px;
        letter-spacing: 1px;
        text-align: left;
        font-weight: 800;
        font-size: 15px;
    }
    .subtotal tr th {
        border-top: 1px solid grey;
        font-family: system-ui, system-ui, sans-serif;
        border-collapse: separate;
        border-spacing: 5px 5px;
        text-align: left;
        font-size: 12px;
    }.grand_total tr th {
         border-top: 2px solid grey;
         font-family: system-ui, system-ui, sans-serif;
         border-collapse: separate;
         border-spacing: 5px 5px;
         text-align: left;
         font-size: 14px;
     }
    .body_class tr td {
        font-family: system-ui, system-ui, sans-serif;
        border-collapse: separate;
        border-spacing: 5px 5px;
        text-align: left;
        font-size: 12px;
    }
    .body_class tbody{
        border-collapse: separate;
        border-spacing: 5px 5px;
        border-bottom: 1px solid;
    }
</style>
<table style="margin-top: 5px;margin-bottom:5px;width: 100%">
    <tbody>
    <tr>
        <td style="width: 25%"> <span style="font-size: 18px;font-weight: bold;">Lender Commission Reconciliation</span></td>
        <td> <span style="width: 60%;">For Statements Received between {{ $date_from.' to '.$date_to }}</span></td>
    </tr>
    </tbody>
</table>

@if(count($lenders)>0)
    <table style="width: 100%;margin-top: 5px" >
        <thead class="thead_style">
        <tr>
            <th>Received</th>
            <th>Agg Upfront</th>
            <th>Trail</th>
            <th>Trail No Gst</th>
            <th>ABP Upfront</th>
            <th>Trail</th>
            <th>Trail No Gst</th>
            <th>Total</th>

        </tr>
        </thead>
        <tbody class="body_class">
    @foreach($lenders as $lender)
        <?php
        $commssions=\App\Models\DealCommission::with('deal','deal.lender')->whereHas('deal.lender',function ($q)use($lender){
            $q->where('lenders.id',$lender->id);
        })->where('date_statement','>=',date('Y-m-d',strtotime($date_from)))
        ->where('date_statement','<=',date('Y-m-d',strtotime($date_to)))
            ->groupBy('date_statement')->get();
        ?>
        <?php
        $total_abp_upfront=0;
        $total_agg_upfront=0;
        $total_abp_no_gst=0;
        $total_agg_no_gst=0;
        $total_abp_gst=0;
        $total_agg_gst=0;
        $total_com=0;

        ?>



            @if(count($commssions))
                <tr style="">
                    <td colspan="8" style="width: 100%;border-bottom: 1px solid"> <span style="font-weight: bold;"><?php
                            echo $lender->code??'';
                            ?></span></td>
                </tr>
                @foreach($commssions as $commssion)
                    <tr>
                        <td>{{ $commssion->date_statement }}</td>
                        <td>
                            <?php
                            echo $agg_upfront=\App\Models\DealCommission::with('deal','deal.lender')->whereHas('deal.lender',function ($q)use($lender){
            $q->where('lenders.id',$lender->id);
        })->whereType(13)->where('date_statement',date('Y-m-d',strtotime($commssion->date_statement)))->sum('agg_amount');
                            $total_agg_upfront=+$agg_upfront;
                            ?>
                        </td>
                        <td><?php
                            echo $agg_gst=\App\Models\DealCommission::with('deal','deal.lender')->whereHas('deal',function ($qu){
                                $qu->where('gst_applies',1);
                            })->whereHas('deal.lender',function ($q)use($lender){
                                $q->where('lenders.id',$lender->id);
                            })->where('date_statement',date('Y-m-d',strtotime($commssion->date_statement)))->whereType(12)->sum('agg_amount');
                            $total_agg_gst+=$agg_gst;
                            ?></td>
                        <td><?php
                            echo $agg_no_gst=\App\Models\DealCommission::with('deal','deal.lender')->whereHas('deal',function ($qu){
                                $qu->where('gst_applies',0);
                            })->whereHas('deal.lender',function ($q)use($lender){
                                $q->where('lenders.id',$lender->id);
                            })->where('date_statement',date('Y-m-d',strtotime($commssion->date_statement)))->whereType(12)->sum('agg_amount');
                            $total_agg_no_gst+=$agg_no_gst;
                            ?></td>
                        <td><?php
                            echo $abp_upfront=\App\Models\DealCommission::with('deal','deal.lender')->whereHas('deal.lender',function ($q)use($lender){
                                $q->where('lenders.id',$lender->id);
                            })->where('date_statement',date('Y-m-d',strtotime($commssion->date_statement)))->whereType(13)->sum('broker_amount');
                            $total_abp_upfront+=$abp_upfront;
                            ?></td>
                        <td>
                            <?php
                            echo $abp_gst=\App\Models\DealCommission::with('deal','deal.lender')->whereHas('deal',function ($qu){
                                $qu->where('gst_applies',1);
                            })->whereHas('deal.lender',function ($q)use($lender){
                                $q->where('lenders.id',$lender->id);
                            })->where('date_statement',date('Y-m-d',strtotime($commssion->date_statement)))->whereType(12)->sum('broker_amount');
                            $total_abp_gst+=$abp_gst;
                            ?>
                        </td>
                        <td>
                            <?php
                            echo $abp_no_gst=\App\Models\DealCommission::with('deal','deal.lender')->whereHas('deal',function ($qu){
                                $qu->where('gst_applies',1);
                            })->whereHas('deal.lender',function ($q)use($lender){
                                $q->where('lenders.id',$lender->id);
                            })->where('date_statement',date('Y-m-d',strtotime($commssion->date_statement)))->whereType(12)->sum('broker_amount');
                            $total_abp_no_gst+=$abp_no_gst;
                            ?>
                        </td>
                        <td>
                            <?php $total=$abp_no_gst+$abp_gst+$abp_upfront+$agg_gst+$agg_upfront+$agg_no_gst;
                            echo $total;
                            $total_com+=$total;
                            ?>
                        </td>
                    </tr>
                @endforeach
            @endif

            <thead class="subtotal">
            <tr>
                <th></th>
                <th>${{ $total_agg_upfront }}</th>
                <th>${{ $total_agg_gst }}</th>
                <th>${{ $total_agg_no_gst }}</th>
                <th>${{ $total_abp_upfront }}</th>
                <th>${{ $total_abp_gst }}</th>
                <th>${{ $total_abp_no_gst }}</th>
                <th>${{ $total_com }}</th>
            </tr>

            </thead>


    @endforeach
    </tbody>
    </table>
@else

    <table style="width: 100%;margin-top: 5px" >
        <thead class="thead_style">
        <tr>
            <th>Received</th>
            <th>Agg Upfront</th>
            <th>Trail</th>
            <th>Trail No Gst</th>
            <th>ABP Upfront</th>
            <th>Trail</th>
            <th>Trail No Gst</th>
            <th>Total</th>
        </tr>
        </thead>
        <tbody class="body_class">
        </tbody>
    </table>
@endif

</body>
</html>
