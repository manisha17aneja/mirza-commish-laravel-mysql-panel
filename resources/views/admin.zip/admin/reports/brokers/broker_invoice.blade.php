<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <title>Pipeline</title>

</head>
<body style=" font-family: system-ui, system-ui, sans-serif;">

<style>
    table {
        border: 0;
        border-collapse: separate;
        border-spacing: 0 5px;
    }

    .thead_style tr th {
        border-bottom: 1px solid grey;
        font-family: system-ui, system-ui, sans-serif;
        border-collapse: separate;
        border-spacing: 5px 5px;
        text-align: left;
        font-weight: 800;
        font-size: 12px;
    }
    .subtotal tr th {
        border-top: 1px solid grey;
        font-family: system-ui, system-ui, sans-serif;
        border-collapse: separate;
        border-spacing: 5px 5px;
        text-align: left;
        font-size: 12px;
    }.grand_total tr th {
         border-top: 2px solid grey;
         font-family: system-ui, system-ui, sans-serif;
         border-collapse: separate;
         border-spacing: 5px 5px;
         text-align: left;
         font-size: 14px;
     }
    .body_class tr td {
        font-family: system-ui, system-ui, sans-serif;
        border-collapse: separate;
        border-spacing: 5px 5px;
        text-align: left;
        font-size: 12px;
    }
    .body_class tbody{
        border-collapse: separate;
        border-spacing: 5px 5px;
        border-bottom: 1px solid;
    }
</style>
<table style="margin-top: 5px;margin-bottom:20px;width: 100%">
    <tbody>
    <tr>
        <td style="width: 25%"> Receipt Created <span style="font-size: 18px;font-weight: bold;">Tax Invoice </span></td>
    </tr>
    </tbody>
</table>
@if(count($brokers)>0)
    @foreach($brokers as $broker)
        <div style="border:1px solid;width: 350px;height: 130px" >
                <div style="margin: 7px">{{$broker->broker->surname}}</div>
                <div style="margin: 7px">{{$broker->broker->business}}</div>
                <span style="margin: 7px">{{$broker->broker->city_info->name}}</span>
                <span style="margin: 0px 7px">{{$broker->broker->state_info->name}}</span>
                <span style="margin: 0px 7px">{{$broker->broker->pincode}}</span>
                <div style="margin: 5px 7px">ABN</div>
                <div style="margin: 2px 7px">{{$broker->broker->abn}}</div>
        </div>
        <?php
            $broker_staffs=\App\Models\CommissionData::whereBrokerId($broker->broker_id)->groupBy('broker_staff_id')->with('broker_staff')->get();
        ?>
        <div style="margin-top: 10px;margin-bottom: 10px;margin-left: 10px">
            <span style="margin-right: 50px; border-bottom: 1px solid">For commission due for the period of </span><span>{{ $date_from.' to '.$date_to }}</span>
        </div>
        <table style="width: 100%;margin-top: 5px" >
            <thead class="thead_style">
            <tr>
                <th>Client</th>
                <th>Institute</th>
                <th>Loan Amount</th>
                <th>Deal Id</th>
                <th>Model</th>
                <th>%</th>
                <th>FMA</th>
                <th>Amount</th>
                <th>Broker</th>
            </tr>
            </thead>
            <tbody class="body_class">
            @foreach($broker_staffs as $broker_staff)
                <?php
                    $deals=\App\Models\CommissionData::whereBrokerStaffId($broker_staff->broker_staff_id)->with('deal','deal.client')->get();
                ?>
            <tr style="border-bottom: 1px solid;padding-bottom: 5px">
                <td style="border-bottom: 1px solid;padding-bottom: 5px" colspan="2"> Broker Staff </td>
                <td style="border-bottom: 1px solid;padding-bottom: 5px;" colspan="7"><span style="background-color:#ffff99">{{ !empty($broker_staffs->broker_staff)?$broker_staffs->broker_staff->surname:'' }}<br>
                        Trail</span>
               </td>
            </tr>
                @foreach($deals as $deal)
                    <tr>
                        <td>{{ $deal->deal->client->surname }}</td>
                        <td>{{ $deal->funder }}</td>
                        <td>{{ $deal->loan_amount }}</td>
                        <td>{{ $deal->deal_id }}</td>
                        <td></td>
                        <td>{{ $deal->rate }}</td>
                        <td>{{ $deal->gst }}</td>
                        <td>{{ $deal->total_paid }}</td>
                        <td>{{ $deal->commission }}</td>
                    </tr>
                @endforeach
            @endforeach
            </tbody>
            <thead class="subtotal">
            <tr>

            </tr>

            </thead>
        </table>

    @endforeach
@else
    <table style="width: 100%;margin-top: 5px" >
        <thead class="thead_style">
        <tr>
            <th>Client</th>
            <th>Institute</th>
            <th>Loan Amount</th>
            <th>Deal Id</th>
            <th>Model</th>
            <th>%</th>
            <th>FMA</th>
            <th>Amount</th>
            <th>Broker</th>
        </tr>
        </thead>
        <tbody class="body_class">
        </tbody>
    </table>
@endif

</body>
</html>
