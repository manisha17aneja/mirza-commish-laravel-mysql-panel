@extends('layout.main')
@section('title')
    Dashboard
@endsection

@section('page_title')
    Dashboard
@endsection
@section('body')

@endsection
